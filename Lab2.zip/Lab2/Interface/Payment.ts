// Wallet Interface with Pay Method and Balance Validation

interface Wallet {
  balance: number;
  pay(amount: number): void;
}

const wallet: Wallet = {
  balance: 500,
  pay(amount: number) {
    if (amount <= this.balance) {
      this.balance -= amount;
      console.log(`Paid R${amount}. Remaining: R${this.balance}`);
    } else {
      console.log("Not enough funds");
    }
  }
};

console.log(`Initial Balance: R${wallet.balance}`);
wallet.pay(200); // Should succeed
wallet.pay(400); // Should fail due to insufficient funds