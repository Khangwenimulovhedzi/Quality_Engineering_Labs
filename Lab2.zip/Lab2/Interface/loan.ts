interface Loan {
  amount: number;
  interestRate: number;
}

const myLoan: Loan = {
  amount: 10000,
  interestRate: 0.05
};

console.log(`Loan amount: ${myLoan.amount}, Interest: ${myLoan.interestRate}`);