// Payment Form Submission with Valid Transaction Details

import { test, expect } from '@playwright/test';

test('User can successfully submit a deposit payment', async ({ page }) => {
  await page.goto('https://quality-engineering-labs.vercel.app/');
  await page.getByLabel('Main navigation').getByRole('link', { name: 'Payment' }).click();
  await page.getByTestId('input-recipient').click();
  await page.getByTestId('input-recipient').fill('Khangweni');
  await page.getByTestId('input-email').click();
  await page.getByTestId('input-email').fill('Khangweni@gmail.com');
  await page.getByTestId('input-pin').click();
  await page.getByTestId('input-pin').fill('123');
  await page.getByTestId('select-txn-type').selectOption('deposit');
  await page.getByTestId('radio-standard').check();
  await page.getByTestId('check-savings').check();
  await page.getByTestId('input-amount').fill('1000');
  await page.getByTestId('check-terms').check();
  await page.getByTestId('submit-btn').click();
  await expect(page.getByTestId('Payment sent successfully')).toBeVisible();
});